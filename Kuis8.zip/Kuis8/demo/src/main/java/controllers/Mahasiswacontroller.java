package com.example.demo.controller.MahasiswaController;

import com.example.demo.model.Mahasiswa;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class MahasiswaController {

    @GetMapping("/mahasiswa")
    public String tampilMahasiswa(Model model) {
        List<Mahasiswa> daftar = new ArrayList<>();
        daftar.add(new Mahasiswa("Ikal", 20));
        daftar.add(new Mahasiswa("Budi", 22));
        daftar.add(new Mahasiswa("Siti", 19));
        model.addAttribute("dataMahasiswa", daftar);
        return "mahasiswa";
    }
}
